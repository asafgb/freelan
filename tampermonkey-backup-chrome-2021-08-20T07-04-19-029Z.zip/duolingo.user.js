// ==UserScript==
// @name         duolingo
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.duolingo.com/learn
// @grant        none
// ==/UserScript==

(function () {

	async function DoAllBackground() {



	//#region  functions

		function sleep(ms) {
			return new Promise(resolve => setTimeout(resolve, ms));
		}

		//#region Firebase
		async function insertFirebase() {
			var d = document
			var script

			script = d.createElement('script');
			script.type = 'text/javascript';
			script.async = true;
			script.onload = function () {
				// remote script has loaded
				console.log("firebase-app.js been loaded")

			};
			script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-app.js';
			d.getElementsByTagName('head')[0].appendChild(script);
			await sleep(2000)


			script = d.createElement('script');
			script.type = 'text/javascript';
			script.async = true;
			script.onload = function () {
				// remote script has loaded
				console.log("firebase-database been loaded")


			};


			script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-database.js';
			d.getElementsByTagName('head')[0].appendChild(script);
			await sleep(2000)




			script = d.createElement('script');
			script.type = 'text/javascript';
			script.async = true;
			script.onload = function () {
				// remote script has loaded
				console.log("firebase-auth been loaded")



				var firebaseConfig = {
					apiKey: "AIzaSyDh8BkywsDcV_CHfzgtTXiXA96Ma6uf8qs",
					authDomain: "autoreport1-ad0df.firebaseapp.com",
					databaseURL: "https://autoreport1-ad0df.firebaseio.com",
					projectId: "autoreport1-ad0df",
					storageBucket: "autoreport1-ad0df.appspot.com",
					messagingSenderId: "253049714136",
					appId: "1:253049714136:web:f07e33e8623b6d2f38eead"
				};
				// // Initialize Firebase
				console.log("before init")
				firebase.initializeApp(firebaseConfig);
				console.log("after init")


			};
			script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-auth.js';
			d.getElementsByTagName('head')[0].appendChild(script);
			await sleep(2000)
		}

		function getDashBoard() {
			var yourName = "Asaf Shazar";
			var spans = document.getElementsByTagName("span")
			var MyObject = objOnText(spans, yourName)
			var parentNode = MyObject.parentNode
			var DashBoard = parentNode.parentNode.parentNode
			return DashBoard
		}

		function getPlayerExp(PlayerName) {
			var dashboard = getDashBoard()
			var spans = dashboard.getElementsByTagName("span")
			var Player = objOnText(spans, PlayerName)
			var PlayerParentNode = Player.parentNode
			var expString = PlayerParentNode.getElementsByTagName("span")[PlayerParentNode.getElementsByTagName("span").length - 1]
			return parseInt(expString.innerText.split(' ')[0])
		}
		function getPlayerNameByRank(rankNumber) // start from 0
		{
			var dashboard = getDashBoard()

			return dashboard.getElementsByTagName("a")[rankNumber].getElementsByTagName("span")[2].innerText
			//dashboard.getElementsByTagName("a")[5].getElementsByTagName("span")[2].innerText
		}

		// rank start with zero == 1 st
		// your name the full name "Asaf Shazar"
		// ThePointBetween if positive I will be above him, if negetive I be below him
		function ReachTheMission(PlayerName, yourName, ThePointBetween, newobject) {
			//debugger;

			var myExp = getPlayerExp(yourName)
			var rankexp = getPlayerExp(PlayerName)
			var msg = "myExp: " + myExp + " MyTarget exp: " + rankexp + " how much I need between " + ThePointBetween + " how much I need more: " + (rankexp + ThePointBetween - myExp)
			console.log(msg)

			if (newobject != null)
			{
				if(newobject.MessageHowManyMorePoints ==null)
				{
					newobject.MessageHowManyMorePoints=""
				}
				newobject.MessageHowManyMorePoints += msg +"\n"
			}

			return (myExp - rankexp) > ThePointBetween
		}
		//new Date('2021-01-21T15:47:00')
		function isTimeArrive(Timelookingfor, newobject) {
			var time = Timelookingfor
			var now = new Date()

			var ticks = new Date(time - new Date()).getTime()
			//ticks= 273800100
			//var miliseconds = ticks%1000;
			ticks = Math.floor(ticks / 1000);
			var seconds = ticks % 60;
			ticks = Math.floor(ticks / 60);
			var min = Math.floor(ticks % 60);
			ticks = Math.floor(ticks / 60);
			var hour = Math.floor(ticks % 24);
			ticks = Math.floor(ticks / 24);
			var days = ticks

			var msg = `Left: ${days} days ${hour}:${min}:${seconds} left`

			console.log(msg)

			if (newobject != null)
			{
				newobject.MessageTimeLeftUntilDone = msg
			}
			//var TimeLeft = new Date(Timelookingfor- new Date() - new Date('01-01-1970 00:00:00')) // start date time
			//var TimeLeft = new Date (new Date('2021-01-22T19:55:00') - new Date()).addYears(-70)
			//var days = TimeLeft.getYear()*365 + TimeLeft.getMonth()*30 +(TimeLeft.getDate()-1)

			return (now.getTime() - time.getTime() > 0)
		}

		//#endregion

		function returnTime(val) {
			if (val == null) {
				val = 0
			}
			var d = new Date();
			d = new Date(d.getTime() + val * 60000);
			return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + " " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
		}

		function uuidv4() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
				var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		}

		/*function objOnText(list, text) {
			var i
			for (i = 0; i < list.length; i++) {
				//if (list[i].innerText == text) {
					if (list[i].innerText.includes(text)) {

					//debugger;
					//alert(i)
					return list[i]//.click()
				}
			}
		}*/

		function objOnText(list, text) {
			var i
			for (i = list.length-1; i > 0; i--) {
					if (list[i].innerText.includes(text)) {

					return list[i]
				}
			}
		}

		function objOnAttribute(list, attributname, text) {
			var i
			for (i = 0; i < list.length; i++) {
				if (list[i].getAttribute(attributname) == text) {
					return list[i]//.innerText
				}
			}
		}

		function objslistonAttribute(list, attributname, text) {
			var returnlist = []
			var i
			for (i = 0; i < list.length; i++) {
				if (list[i].getAttribute(attributname) == text) {
					returnlist.push(list[i])
				}
			}
			return returnlist;
		}

		async function clickByString(listButtons, stringComplete) {
			var alreadyUsed = []
			var clickbyOrder = stringComplete.split(" ")
			var i, j
			for (i = 0; i < clickbyOrder.length; i++) {
				for (j = 0; j < listButtons.length; j++) {
					if (clickbyOrder[i] == listButtons[j].innerText && !(alreadyUsed.includes(listButtons[j]))) {
						alreadyUsed.push(listButtons[j])
						listButtons[j].click()
						await sleep(400)
						j = listButtons.length
					}
				}
			}
		}

	//#endregion

		await insertFirebase()
		async function Playing() {

			//var times = 50
			//var runtime
			//for (runtime = 1; runtime < times; times++) {
			var times = 4
			var missionreach =false
			var dateReach = false
			while (true) {
				times--

				while ((!(missionreach)) && !(dateReach)) {
					var newobject = {}
					/////var database = firebase.database()
					/////var valrequest = await firebase.database().ref('Duolingo').once('value')
					/////var Alljson = valrequest.val()

					/////Alljson.LastUpdate = returnTime();
					/////Alljson.lst.push(newobject)

					/////newobject.GuidLastRun = uuidv4();
					/////newobject.messageSatus = "Starting"
					/////await database.ref('Duolingo').set(Alljson)

					/// START THE GAME
					var divs = document.getElementsByTagName("div")
					var i, buttons, PRACTICE

					buttons = document.getElementsByTagName("a")
					PRACTICE = objOnText(buttons, "PRACTICE")

					if (PRACTICE == null) {

						var Which=Math.floor(Math.random() * 12)

						if(Which <=5)
						{
							var Flirting = objOnText(divs, "Flirting")
							Flirting.click()
							await sleep(1000)
						}
						else
						{
							var Idioms = objOnText(divs, "Idioms")
							Idioms.click()
							await sleep(1000)
						}

						buttons = document.getElementsByTagName("a")
						PRACTICE = objOnText(buttons, "PRACTICE")
						PRACTICE.click()
						await sleep(6000)
					}
					else {
						PRACTICE.click()
						await sleep(6000)
					}

					/////Alljson.LastUpdate = returnTime();
					/////newobject.messageSatus = "Click Practice"
					/////await database.ref('Duolingo').set(Alljson)


					/// START SOLVING
					var done = false
					var solvenum = 1;
					var bar=objOnAttribute(document.getElementsByTagName("div"),"aria-valuenow",0);
					while (!done) {
						var tmplst, check
						/////Alljson.LastUpdate = returnTime();
						/////newobject.messageSatus = "Solve number: " + solvenum;
						/////await database.ref('Duolingo').set(Alljson)
						solvenum++;

						var spans = document.getElementsByTagName("span")
						var sentence = "";
						sentence = objOnAttribute(spans, "data-test", "hint-sentence")


						tmplst = document.getElementsByTagName("button")
						//debugger;
						var sentnceclickablelist = objslistonAttribute(tmplst, "data-test", "challenge-tap-token")
						switch (sentence.innerText) {
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "Your hairstyle is beautiful")
								break;
							case "Tu veux être mon petit copain ?":
								await clickByString(sentnceclickablelist, "Do you want to be my boyfriend")
								break;
							case "Ta robe est d'une grande beauté":
								await clickByString(sentnceclickablelist, "Your dress is beautiful")
								break;
							case "Ton maquillage est d'une grande beauté":
								await clickByString(sentnceclickablelist, "Your make up is beautiful")
								break;
							case "Salut beau gosse, comment tu t'appelles ?":
								await clickByString(sentnceclickablelist, "Hello handsome what's your name")
								break;
							case "Tu t'appelles comment ?":
								await clickByString(sentnceclickablelist, "What's your name")
								break;
							case "J'aimerais vivre dans tes chaussures pour être avec toi à chacun de tes pas.":
								await clickByString(sentnceclickablelist, "I want to live in your shoes so I can be with you every step of the way")
								break;
							case "Je peux vous offrir un verre ?":
								await clickByString(sentnceclickablelist, "Can I buy you a drink")
								break;
							case "C'est le prince charmant !":
								await clickByString(sentnceclickablelist, "He is Prince Charming")
								break;
							case "Voulez-vous aller prendre un verre ?":
								await clickByString(sentnceclickablelist, "Would you like to go get a drink")
								break;
							case "Je suis tombé amoureux de toi":
								await clickByString(sentnceclickablelist, "I have fallen in love with you")
								break;
							case "Tu es mannequin ?":
								await clickByString(sentnceclickablelist, "Are you a model")
								break;
							case "Tu me plais.":
								await clickByString(sentnceclickablelist, "I like you")
								break;
							case "Je ne suis pas saoul, je suis juste ivre de vous.":
								await clickByString(sentnceclickablelist, "I'm not drunk , I'm just intoxicated by you")
								break;
							case "Vous venez ici souvent ?":
								await clickByString(sentnceclickablelist, "Do you come here often")
								break;
							case "Voulez-vous danser avec moi ?":
								await clickByString(sentnceclickablelist, "Do you want to dance with me")
								break;
							case "Toutes les bonnes choses ont une fin.":
								await clickByString(sentnceclickablelist, "All good things come to an end")
								break;
							case "Sauve qui peut !"	:
							await clickByString(sentnceclickablelist, "Run for your life")
								break;
							case "Ce type ne t'arrive pas à la cheville, crois-moi !":
								await clickByString(sentnceclickablelist, "This guy does not play in the same league as you , believe me")
								break;
							case "Le monde appartient à ceux qui se lèvent tôt.":
								await clickByString(sentnceclickablelist, "The early bird catches the worm")
								break;
							case "Il y a de bonnes choses à manger, si le cœur vous en dit !":
								await clickByString(sentnceclickablelist, "There are good things to eat , if you feel like it")
								break;
							case "Mieux vaut tard que jamais.":
								await clickByString(sentnceclickablelist, "Better late than never")
								break;
							case "Elle va gagner les doigts dans le nez !":
								await clickByString(sentnceclickablelist, "She is going to win hands down")
								break;
							case "Qui va à la chasse, perd sa place.":
								await clickByString(sentnceclickablelist, "Move your feet , lose your seat")
								break;
							case "Je n'en crois pas mes yeux !":
								await clickByString(sentnceclickablelist, "I can't believe my eyes")
								break;
							case "L'herbe est toujours plus verte chez le voisin.":
								await clickByString(sentnceclickablelist, "The grass is always greener on the other side")
								break;
							case "Les absents ont toujours tort.":
								await clickByString(sentnceclickablelist, "The absent are always in the wrong")
								break;
							case "Loin des yeux, loin du cœur.":
								await clickByString(sentnceclickablelist, "Out of sight , out of mind")
								break;
							case "Même pas mal !":
								await clickByString(sentnceclickablelist, "Did not even hurt me")
								break;
							case "C'est n'importe quoi.":
								await clickByString(sentnceclickablelist, "That is nonsense")
								break;
							case "Ça va, ça vient.":
								await clickByString(sentnceclickablelist, "Easy come , easy go")
								break;
							case "Cet enfant ne sait pas tenir sa langue.":
								await clickByString(sentnceclickablelist, "This child cannot hold his tongue")
								break;
							case "Au secours !":
								await clickByString(sentnceclickablelist, "Help")
								break;
							case "Ne coupons pas les cheveux en quatre !":
								await clickByString(sentnceclickablelist, "Let 's not split hairs")
								break;
							case "Cette voiture coûte un bras.":
								await clickByString(sentnceclickablelist, "That car costs an arm and a leg")
								break;
							case "À chacun ses goûts.":
								await clickByString(sentnceclickablelist, "To each his own")
								break;
							case "Les murs ont des oreilles.":
								await clickByString(sentnceclickablelist, "The walls have ears")
								break;
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "")
								break;
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "")
								break;
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "")
								break;
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "")
								break;
							case "Ta coiffure est d'une grande beauté":
								await clickByString(sentnceclickablelist, "")
								break;
							default:
								alert("welp!!!")
								debugger;
								break;
						}
						debugger;
						check = objOnAttribute(tmplst, "data-test", "player-next")


						sentencetmp = null
						while((parseFloat(bar.getAttribute("aria-valuenow"))!=1.0 && sentencetmp == null )|| ((sentencetmp !=null) && sentencetmp.innerText == sentence.innerText))
						{
							check.click()
							await sleep(2000)
							var spanstmp = document.getElementsByTagName("span")
							var sentencetmp = "";
							sentencetmp = objOnAttribute(spanstmp, "data-test", "hint-sentence")
						}

						await sleep(1000)

						if (sentencetmp == null) {
							done = true
							while (check != null) {
								check.click()
								tmplst = document.getElementsByTagName("button")
								check = objOnAttribute(tmplst, "data-test", "player-next")
								await sleep(2000)
							}
						}

					} // end while

					/////newobject.messageSatus = "Done this run"
					/////Alljson.LastUpdate = returnTime();
					/////newobject.TimeFinish = returnTime();

					//debugger;
					var timetosleep = 3 + Math.floor(Math.random() * 6);
					var sleepMin = timetosleep * 60 * 1000;
					/////newobject.CoupleOfWaitMin = timetosleep;//+" Minutes";
					/////newobject.TimeShouldStartNew = returnTime(timetosleep);
					/////await database.ref('Duolingo').set(Alljson)


					//location.href = "https://brabrabra.com/";
					//await sleep(sleepMin)

					var point = 0
					try
					{
						point = Math.max(point,ReachTheMission("MUKESH", "Asaf Shazar", 2800, newobject))
					}
					catch{}
					try
					{
						point = Math.max(point,ReachTheMission(getPlayerNameByRank(1), "Asaf Shazar", 2800, newobject))
					}
					catch{}
					missionreach =point
				 	dateReach = isTimeArrive(new Date('2021-05-011T02:35:00'), newobject)

				} // end second while

				if ((dateReach)) {
					location.href = "https://brabrabra.com/"
				}
				else if (times <= 0) {

					location.reload();
				}
				await sleep(60000)
			}// end first while
		}



		Playing();








	} // background function
	setTimeout(function () {
		DoAllBackground()

	}, 3000);

})();