// ==UserScript==
// @name         read.e-vrit.
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://read.e-vrit.co.il/reader
// @grant        none
// ==/UserScript==

let Url="";
(function() {
    'use strict';
	//debugger;
		setTimeout(Start, 4000);
})();


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function insertFirebase() {
    var d = document
    var script

    script = d.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.onload = function () {
        // remote script has loaded
        console.log("firebase-app.js been loaded")

    };
    script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-app.js';
    d.getElementsByTagName('head')[0].appendChild(script);
    await sleep(2000)


    script = d.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.onload = function () {
        // remote script has loaded
        console.log("firebase-database been loaded")


    };


    script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-database.js';
    d.getElementsByTagName('head')[0].appendChild(script);
    await sleep(2000)




    script = d.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.onload = function () {
        // remote script has loaded
        console.log("firebase-auth been loaded")



        var firebaseConfig = {
            apiKey: "AIzaSyDh8BkywsDcV_CHfzgtTXiXA96Ma6uf8qs",
            authDomain: "autoreport1-ad0df.firebaseapp.com",
            databaseURL: "https://autoreport1-ad0df.firebaseio.com",
            projectId: "autoreport1-ad0df",
            storageBucket: "autoreport1-ad0df.appspot.com",
            messagingSenderId: "253049714136",
            appId: "1:253049714136:web:f07e33e8623b6d2f38eead"
        };
        // // Initialize Firebase
        console.log("before init")
        firebase.initializeApp(firebaseConfig);
        console.log("after init")


    };
    script.src = 'https://www.gstatic.com/firebasejs/6.5.0/firebase-auth.js';
    d.getElementsByTagName('head')[0].appendChild(script);
    await sleep(2000)
}

async function Start()
{
   await insertFirebase()

    //setInterval(async function() {
 await Update()

//}, 3000);
//alert("Done3")
   //var newobject = {}
   //newobject["html"]=""
   //var database = firebase.database()
   //await database.ref('read').set(newobject)

}

async function Update()
{
    var database = firebase.database()
    var valrequest = await database.ref('read').once('value')
    var Alljson = valrequest.val()
    //Alljson["html"]=document.documentElement.outerHTML
    alert("from now 10 sec to record")
    await sleep(10000)
    Alljson["body1"]=""
    await database.ref('read').set(Alljson)
    var done =false
    while(!done)
    {
        if(!(document.getElementsByTagName("iframe")[0].contentDocument.body.innerText.includes("נו, איך היה?")))
        {
            Alljson["body1"]+=document.getElementsByTagName("iframe")[0].contentDocument.documentElement.innerText
            document.getElementsByClassName("chapter-button__label")[1].click()
            await database.ref('read').set(Alljson)
            await sleep(2000)
        }else
        {
            done=true
        }
    }
    alert("done")

    //alert(document.getElementsByClassName("viewer-container")[0].innerHTML)
    //Alljson["body1"]=document.getElementsByClassName("viewer-container")[0].innerText
    //alert("work")
}
