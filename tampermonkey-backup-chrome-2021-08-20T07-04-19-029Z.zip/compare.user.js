// ==UserScript==
// @name         compare
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.steamtradematcher.com/compare
// @grant        none
// ==/UserScript==

(function() {
    'use strict';


	async function DoAllBackground() {


//	debugger;
	await sleep(5000)
    if(document.getElementsByTagName("body")[0].innerText =="Sorry, there is too much load on the server at the moment. Please retry later.")
    {
        location.reload();
    }

	}

	function sleep(ms) {
	  return new Promise(resolve => setTimeout(resolve, ms));
	}


	DoAllBackground()


    // Your code here...
})();