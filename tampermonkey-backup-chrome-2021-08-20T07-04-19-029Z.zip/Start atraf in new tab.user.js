// ==UserScript==
// @name         Start atraf in new tab
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://dating.atraf.co.il/*
// @grant        none
// ==/UserScript==

let Url="";
(function() {
    'use strict';
	//debugger;
		setTimeout(Start, 3000);

})();

function Start()
{
	//if(!document.head.innerText.includes("Clicked(url)"))
    if(document.title.includes("אטרף דייטינג")|| document.title == "atrafDating")
	{
		doesThings()
		Url = window.location.href
		setInterval(ChechChangeSiteURL, 3000);
	}
}

function doesThings()
{
	var divs = document.getElementsByTagName("div")

	for(var i =0;i<divs.length;i++)
	{

		var div = divs[i];

		if(div.getAttribute("href") !=null)
		{
			var text = div.getAttribute("href")
			div.removeAttribute("href")
			div.setAttribute("onclick","Clicked('"+text+"')")
		}
	}
	var script = document.createElement( 'script' );
	script.type = 'text/javascript';
	script.innerHTML = function Clicked(url){
				debugger;
				window.open(window.location.origin+url);
				}
	$("head").append( script );

	//alert("done");
	//Start = function(){};
}

function ChechChangeSiteURL()
{
	//console.log(document.readyState)
	if(Url != window.location.href && document.getElementById("contentMain").innerText != "")
	{
		Url = window.location.href
		doesThings()
	}
}




