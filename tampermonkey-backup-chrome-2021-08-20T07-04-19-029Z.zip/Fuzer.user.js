// ==UserScript==
// @name         Fuzer
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.fuzer.me/browse.php?*order=size&sort=asc*
// @grant        none
// ==/UserScript==


 function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

var getParams = function (url) {
	var params = {};
	var parser = document.createElement('a');
	parser.href = url;
	var query = parser.search.substring(1);
	var vars = query.split('&');
	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split('=');
		params[pair[0]] = decodeURIComponent(pair[1]);
	}
	return params;
};


(function() {

setTimeout(function(){


var a = document.getElementsByClassName("dlimg dlimg-purple_dl")
//var b = document.getElementsByClassName("dlimg dlimg-new_dl")
//var c = document.getElementsByClassName("dlimg dlimg-yellow_dl")
var d = document.getElementsByClassName(" dlimg dlimg-green_dl")
var i

for( i =0; i < a.length; i++)
{
	a[i].click()
	sleep(1700)

}

/*
for(i =0; i < b.length; i++)
{
	b[i].click()
	sleep(1700)

}

for(i =0; i < c.length; i++)
{
	c[i].click()
	sleep(1700)
}*/

for(i =0; i < d.length; i++)
{
	d[i].click()
	sleep(1700)
}

var params = getParams (window.location.href)
var pageNum = parseInt(params.page)
var nextPage = pageNum +1

if(nextPage < 9)
{
    window.location.href= window.location.href.replace("page="+pageNum,"page="+nextPage)
}
 }, 3000);

})();