// ==UserScript==
// @name         www.yaoihavenreborn
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.yaoihavenreborn.com/*
// @grant        none
// ==/UserScript==



(function() {

	async function DoAllBackground() {


//	debugger;
	await sleep(1000)
    var parts = document.body.scrollHeight/60
    var i=0
    while(parts*i < document.body.scrollHeight)
    {
        window.scrollTo(0,parts*i);
        await sleep(50)
        i++
    }
	window.scrollTo(0,document.body.scrollHeight);
	await sleep(2000)
	window.scrollTo(0,0);

	if(document.getElementsByClassName("btn btn-success c-pointer")[0] != null)
	{
		document.getElementsByClassName("btn btn-success c-pointer")[0].click()
	}

	}

	function sleep(ms) {
	  return new Promise(resolve => setTimeout(resolve, ms));
	}


	DoAllBackground()
})();